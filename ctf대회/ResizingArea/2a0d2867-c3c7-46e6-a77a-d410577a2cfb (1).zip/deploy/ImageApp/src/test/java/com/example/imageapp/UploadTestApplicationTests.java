package com.example.imageapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UploadTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
